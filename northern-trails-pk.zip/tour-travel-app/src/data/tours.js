export const regions = ["All", "Hunza", "Skardu", "Fairy Meadows", "Naran-Kaghan", "Neelum Valley", "Deosai"]

export const tours = [
  {
    id: "t01",
    name: "Hunza Valley Trail",
    region: "Hunza",
    country: "Gilgit-Baltistan",
    days: 5,
    distanceKm: 58,
    elevationM: 2438,
    difficulty: "Easy",
    price: 55000,
    tagline: "Apricot orchards, Attabad's turquoise water, and Baltit Fort at dusk.",
    image: "linear-gradient(160deg,#2f4538 0%,#8a9b7e 55%,#e8dfc8 100%)",
    itinerary: [
      { day: 1, title: "Islamabad → Karimabad", detail: "Karakoram Highway drive along the Indus and Hunza rivers." },
      { day: 2, title: "Baltit & Altit Forts", detail: "Old town walk, views over the Hunza valley floor." },
      { day: 3, title: "Attabad Lake → Passu Cones", detail: "Boat ride on the lake, short walk to the Passu glacier viewpoint." },
      { day: 4, title: "Duiker viewpoint sunrise", detail: "Jeep track above Karimabad for the Rakaposhi panorama." },
      { day: 5, title: "Return to Gilgit", detail: "Stop at the Rakaposhi viewpoint en route." }
    ]
  },
  {
    id: "t02",
    name: "Skardu & Basho Valley",
    region: "Skardu",
    country: "Gilgit-Baltistan",
    days: 6,
    distanceKm: 82,
    elevationM: 3200,
    difficulty: "Moderate",
    price: 78000,
    tagline: "Desert cold lakes, pine forest, and the gateway to the giants.",
    image: "linear-gradient(160deg,#5b3d2b 0%,#b5562d 55%,#e8dfc8 100%)",
    itinerary: [
      { day: 1, title: "Gilgit → Skardu", detail: "Drive along the Indus through Basha and Katzarah." },
      { day: 2, title: "Upper Kachura Lake", detail: "Shangrila resort and cold desert dunes at Skardu." },
      { day: 3, title: "Basho Valley entry", detail: "Pine forest camp beside the Basho stream." },
      { day: 4, title: "Basho meadows", detail: "Day hike to the upper pastures at 3,200m." },
      { day: 5, title: "Shigar Fort & valley", detail: "Old caravan route, apricot terraces." },
      { day: 6, title: "Return to Skardu", detail: "Free evening at Skardu bazaar before departure." }
    ]
  },
  {
    id: "t03",
    name: "Fairy Meadows & Nanga Parbat Base Camp",
    region: "Fairy Meadows",
    country: "Gilgit-Baltistan",
    days: 5,
    distanceKm: 34,
    elevationM: 3900,
    difficulty: "Challenging",
    price: 65000,
    tagline: "Face to face with the ninth-highest peak on earth.",
    image: "linear-gradient(160deg,#1b2420 0%,#5b6b62 55%,#f6f3ea 100%)",
    itinerary: [
      { day: 1, title: "Raikot Bridge → Tato village", detail: "Jeep track climb off the Karakoram Highway." },
      { day: 2, title: "Tato → Fairy Meadows", detail: "Forest trek to the meadow camp at 3,300m." },
      { day: 3, title: "Beyal Camp", detail: "Trek closer to Nanga Parbat's south face." },
      { day: 4, title: "Nanga Parbat viewpoint", detail: "Base camp views at 3,900m, glacier in view." },
      { day: 5, title: "Descent to Raikot Bridge", detail: "Return jeep transfer to the highway." }
    ]
  },
  {
    id: "t04",
    name: "Naran, Saif-ul-Malook & Babusar",
    region: "Naran-Kaghan",
    country: "Khyber Pakhtunkhwa",
    days: 4,
    distanceKm: 46,
    elevationM: 4173,
    difficulty: "Moderate",
    price: 38000,
    tagline: "Alpine lakes and the highest paved pass in the Kaghan valley.",
    image: "linear-gradient(160deg,#3a4f3f 0%,#8a9b7e 55%,#f6f3ea 100%)",
    itinerary: [
      { day: 1, title: "Abbottabad → Naran", detail: "Kaghan valley drive alongside the Kunhar river." },
      { day: 2, title: "Lake Saif-ul-Malook", detail: "Jeep to the lake, short walk around the shore." },
      { day: 3, title: "Lulusar Lake", detail: "High-altitude lake en route to Babusar." },
      { day: 4, title: "Babusar Top crossing", detail: "4,173m pass, views into Chilas and the Karakoram." }
    ]
  },
  {
    id: "t05",
    name: "Neelum Valley & Ratti Gali",
    region: "Neelum Valley",
    country: "Azad Kashmir",
    days: 5,
    distanceKm: 51,
    elevationM: 3600,
    difficulty: "Moderate",
    price: 48000,
    tagline: "Pine-covered slopes and an alpine lake the colour of glass.",
    image: "linear-gradient(160deg,#2f4538 0%,#5b6b62 55%,#f6f3ea 100%)",
    itinerary: [
      { day: 1, title: "Muzaffarabad → Kutton", detail: "Drive up the Neelum river valley." },
      { day: 2, title: "Arang Kel", detail: "Chairlift and forest walk to the plateau village." },
      { day: 3, title: "Ratti Gali base", detail: "Jeep track to the trailhead at Dowarian." },
      { day: 4, title: "Ratti Gali Lake", detail: "Trek to the lake at 3,600m, snowfields even in summer." },
      { day: 5, title: "Return to Muzaffarabad", detail: "Stop at Kutton waterfalls." }
    ]
  },
  {
    id: "t06",
    name: "Deosai Plains Crossing",
    region: "Deosai",
    country: "Gilgit-Baltistan",
    days: 4,
    distanceKm: 63,
    elevationM: 4114,
    difficulty: "Challenging",
    price: 58000,
    tagline: "The Land of Giants — wildflowers, brown bears, and empty horizon.",
    image: "linear-gradient(160deg,#1b2420 0%,#2f4538 55%,#5b6b62 100%)",
    itinerary: [
      { day: 1, title: "Skardu → Deosai gate", detail: "Ascent onto the plateau at Sadpara." },
      { day: 2, title: "Sheosar Lake", detail: "Camp beside the lake at 4,114m." },
      { day: 3, title: "Bara Pani wildlife watch", detail: "Best chance of spotting the Himalayan brown bear." },
      { day: 4, title: "Descent to Astore", detail: "Exit via the Astore valley road." }
    ]
  }
]
