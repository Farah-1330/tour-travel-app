export default function Footer() {
  return (
    <footer className="footer" id="contact">
      <div className="footer__row">
        <div>
          <p className="footer__mark">◈ Northern Trails PK</p>
          <p className="footer__note">Guided treks across northern Pakistan. Departures April–October, weather permitting.</p>
        </div>
        <div className="footer__links">
          <div>
            <p className="footer__heading">Regions</p>
            <p>Hunza</p>
            <p>Skardu</p>
            <p>Fairy Meadows</p>
            <p>Naran-Kaghan</p>
            <p>Neelum Valley</p>
            <p>Deosai</p>
          </div>
          <div>
            <p className="footer__heading">Studio</p>
            <p>Guides</p>
            <p>Safety notes</p>
            <p>Contact</p>
          </div>
        </div>
      </div>
      <p className="footer__fine">Built as a React learning project — component decomposition, props drilling, CSS in React.</p>
    </footer>
  )
}
