import { useState } from 'react'

export default function Header() {
  const [open, setOpen] = useState(false)

  const links = ["Routes", "Guides", "Journal", "Contact"]

  return (
    <header className="header">
      <div className="header__row">
        <a href="#top" className="header__mark" onClick={() => setOpen(false)}>
          <span className="header__compass" aria-hidden="true">◈</span>
          Northern Trails PK
        </a>

        <nav className={`header__nav ${open ? "header__nav--open" : ""}`}>
          {links.map((link) => (
            <a key={link} href={`#${link.toLowerCase()}`} onClick={() => setOpen(false)}>
              {link}
            </a>
          ))}
          <a href="#routes" className="header__cta" onClick={() => setOpen(false)}>
            View routes
          </a>
        </nav>

        <button
          className="header__toggle"
          aria-label={open ? "Close menu" : "Open menu"}
          aria-expanded={open}
          onClick={() => setOpen((v) => !v)}
        >
          <span />
          <span />
          <span />
        </button>
      </div>
    </header>
  )
}
