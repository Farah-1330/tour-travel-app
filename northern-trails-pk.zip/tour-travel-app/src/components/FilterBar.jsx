// Controlled component: FilterBar holds no state of its own.
// activeRegion/searchTerm come down as props, changes go back up via callbacks.
export default function FilterBar({ regions, activeRegion, onRegionChange, searchTerm, onSearchChange, resultCount }) {
  return (
    <div className="filter-bar">
      <div className="filter-bar__chips">
        {regions.map((region) => (
          <button
            key={region}
            className={`filter-bar__chip ${activeRegion === region ? "filter-bar__chip--active" : ""}`}
            onClick={() => onRegionChange(region)}
          >
            {region}
          </button>
        ))}
      </div>

      <div className="filter-bar__search">
        <input
          type="search"
          placeholder="Search a route or country…"
          value={searchTerm}
          onChange={(e) => onSearchChange(e.target.value)}
          aria-label="Search routes"
        />
        <span className="filter-bar__count">{resultCount} shown</span>
      </div>
    </div>
  )
}
