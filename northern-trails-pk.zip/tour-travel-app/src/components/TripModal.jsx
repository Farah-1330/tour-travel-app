import { useEffect } from 'react'

// Receives the selected tour as a prop (or null) and a close callback.
// App owns the "which tour is open" state; this component is purely
// presentational so it can't drift out of sync with the rest of the page.
export default function TripModal({ tour, onClose }) {
  useEffect(() => {
    const onKey = (e) => e.key === "Escape" && onClose()
    document.addEventListener("keydown", onKey)
    document.body.style.overflow = tour ? "hidden" : ""
    return () => {
      document.removeEventListener("keydown", onKey)
      document.body.style.overflow = ""
    }
  }, [tour, onClose])

  if (!tour) return null

  return (
    <div className="modal" role="dialog" aria-modal="true" aria-label={`${tour.name} itinerary`}>
      <div className="modal__backdrop" onClick={onClose} />
      <div className="modal__panel">
        <button className="modal__close" onClick={onClose} aria-label="Close itinerary">×</button>

        <div className="modal__hero" style={{ background: tour.image }} />

        <div className="modal__content">
          <p className="modal__region">{tour.region} · {tour.country}</p>
          <h2 className="modal__title">{tour.name}</h2>
          <p className="modal__tagline">{tour.tagline}</p>

          <div className="modal__stats">
            <div><span>{tour.days}</span>days</div>
            <div><span>{tour.distanceKm}</span>km</div>
            <div><span>{tour.elevationM.toLocaleString()}</span>m high point</div>
            <div><span>Rs {tour.price.toLocaleString()}</span>per person</div>
          </div>

          <h3 className="modal__subhead">Day by day</h3>
          <ol className="modal__itinerary">
            {tour.itinerary.map((stop) => (
              <li key={stop.day}>
                <span className="modal__day">{String(stop.day).padStart(2, "0")}</span>
                <div>
                  <p className="modal__day-title">{stop.title}</p>
                  <p className="modal__day-detail">{stop.detail}</p>
                </div>
              </li>
            ))}
          </ol>

          <button className="modal__book" onClick={onClose}>
            Request a spot on this route
          </button>
        </div>
      </div>
    </div>
  )
}
