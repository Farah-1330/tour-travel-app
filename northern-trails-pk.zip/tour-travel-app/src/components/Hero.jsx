import StatBadge from './StatBadge.jsx'

// Hero receives its stats as props from App — no hardcoded numbers here,
// so the same component would work for any future dataset.
export default function Hero({ tripCount, regionCount, totalDistanceKm }) {
  return (
    <section className="hero" id="top">
      <div className="hero__contours" aria-hidden="true">
        <svg viewBox="0 0 600 400" preserveAspectRatio="none">
          <path d="M-20,340 C120,300 180,380 320,320 C440,270 480,340 620,300" />
          <path d="M-20,300 C120,260 180,340 320,280 C440,230 480,300 620,260" />
          <path d="M-20,260 C120,220 180,300 320,240 C440,190 480,260 620,220" />
        </svg>
      </div>

      <p className="hero__eyebrow">Small-group trekking across Gilgit-Baltistan, KPK & Kashmir</p>
      <h1 className="hero__title">
        Go where the <em>map</em> runs out.
      </h1>
      <p className="hero__lede">
        Northern Trails PK runs {tripCount} guided routes across {regionCount} regions of northern Pakistan —
        Hunza's orchards, Skardu's cold desert, Fairy Meadows, and the high passes most itineraries skip entirely.
      </p>

      <div className="hero__stats">
        <StatBadge label="Guided routes" value={tripCount} />
        <StatBadge label="Northern regions" value={regionCount} />
        <StatBadge label="Trail km mapped" value={`${totalDistanceKm}+`} />
      </div>

      <a href="#routes" className="hero__scroll">
        See the routes ↓
      </a>
    </section>
  )
}
