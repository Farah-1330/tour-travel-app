const quotes = [
  {
    text: "Sheosar Lake at sunrise, no one else on the plateau. Worth every hour of the jeep track.",
    name: "A. Raza",
    trip: "Deosai Plains Crossing"
  },
  {
    text: "The guide got us to the Nanga Parbat viewpoint just as the clouds cleared on day four.",
    name: "S. Bibi",
    trip: "Fairy Meadows & Nanga Parbat Base Camp"
  },
  {
    text: "Attabad's colour still doesn't look real in photos. Karimabad in the evening light was the highlight.",
    name: "H. Malik",
    trip: "Hunza Valley Trail"
  }
]

export default function Testimonials() {
  return (
    <section className="testimonials" id="journal">
      <h2 className="testimonials__title">From the trail register</h2>
      <p className="testimonials__sub" style={{ marginTop: "-20px", marginBottom: "24px", color: "#5b6b62" }}>
        Notes from travelers who've done these routes with us.
      </p>
      <div className="testimonials__grid">
        {quotes.map((q) => (
          <figure key={q.name} className="testimonials__card">
            <blockquote>“{q.text}”</blockquote>
            <figcaption>
              <strong>{q.name}</strong> — {q.trip}
            </figcaption>
          </figure>
        ))}
      </div>
    </section>
  )
}
