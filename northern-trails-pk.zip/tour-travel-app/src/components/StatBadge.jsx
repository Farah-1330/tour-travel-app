// Reusable small component — receives everything via props, no internal data.
export default function StatBadge({ label, value }) {
  return (
    <div className="stat-badge">
      <span className="stat-badge__value">{value}</span>
      <span className="stat-badge__label">{label}</span>
    </div>
  )
}
