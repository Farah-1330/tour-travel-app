import TourCard from './TourCard.jsx'

// TourList never touches tour fields directly — it only receives the
// filtered array from App and the onSelect callback, then drills both
// down into each TourCard. This is the props-drilling link in the tree.
export default function TourList({ tours, onSelect }) {
  if (tours.length === 0) {
    return (
      <p className="tour-list__empty">
        No routes match that search. Try a different region or clear the search box.
      </p>
    )
  }

  return (
    <div className="tour-list" id="routes">
      {tours.map((tour) => (
        <TourCard key={tour.id} tour={tour} onSelect={onSelect} />
      ))}
    </div>
  )
}
