// Reusable card: takes one "tour" object and a click handler as props.
// It renders nothing it wasn't handed — this is what lets TourList
// reuse it for any tour without special-casing.
export default function TourCard({ tour, onSelect }) {
  return (
    <article className="tour-card">
      <div className="tour-card__image" style={{ background: tour.image }}>
        <span className="tour-card__difficulty">{tour.difficulty}</span>
      </div>
      <div className="tour-card__body">
        <p className="tour-card__region">{tour.region} · {tour.country}</p>
        <h3 className="tour-card__name">{tour.name}</h3>
        <p className="tour-card__tagline">{tour.tagline}</p>

        <dl className="tour-card__meta">
          <div>
            <dt>Days</dt>
            <dd>{tour.days}</dd>
          </div>
          <div>
            <dt>Distance</dt>
            <dd>{tour.distanceKm} km</dd>
          </div>
          <div>
            <dt>High point</dt>
            <dd>{tour.elevationM.toLocaleString()} m</dd>
          </div>
        </dl>

        <div className="tour-card__footer">
          <span className="tour-card__price">Rs {tour.price.toLocaleString()}</span>
          <button className="tour-card__cta" onClick={() => onSelect(tour)}>
            View itinerary
          </button>
        </div>
      </div>
    </article>
  )
}
