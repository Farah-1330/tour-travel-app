import { useMemo, useState } from 'react'
import Header from './components/Header.jsx'
import Hero from './components/Hero.jsx'
import FilterBar from './components/FilterBar.jsx'
import TourList from './components/TourList.jsx'
import TripModal from './components/TripModal.jsx'
import Testimonials from './components/Testimonials.jsx'
import Footer from './components/Footer.jsx'
import { tours, regions } from './data/tours.js'

export default function App() {
  // All shared state lives here in App and is drilled down as props —
  // FilterBar and TourList never talk to each other directly.
  const [activeRegion, setActiveRegion] = useState("All")
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedTour, setSelectedTour] = useState(null)

  const filteredTours = useMemo(() => {
    return tours.filter((tour) => {
      const matchesRegion = activeRegion === "All" || tour.region === activeRegion
      const query = searchTerm.trim().toLowerCase()
      const matchesSearch =
        query === "" ||
        tour.name.toLowerCase().includes(query) ||
        tour.country.toLowerCase().includes(query)
      return matchesRegion && matchesSearch
    })
  }, [activeRegion, searchTerm])

  const totalDistanceKm = useMemo(
    () => tours.reduce((sum, t) => sum + t.distanceKm, 0),
    []
  )

  return (
    <>
      <Header />

      <main>
        <Hero
          tripCount={tours.length}
          regionCount={regions.length - 1}
          totalDistanceKm={totalDistanceKm}
        />

        <section className="routes-section">
          <FilterBar
            regions={regions}
            activeRegion={activeRegion}
            onRegionChange={setActiveRegion}
            searchTerm={searchTerm}
            onSearchChange={setSearchTerm}
            resultCount={filteredTours.length}
          />

          <TourList tours={filteredTours} onSelect={setSelectedTour} />
        </section>

        <Testimonials />
      </main>

      <Footer />

      <TripModal tour={selectedTour} onClose={() => setSelectedTour(null)} />
    </>
  )
}
